(function ( $ ) {
	window.InlineShortcodeView_vc_tta_pageable = window.InlineShortcodeView_vc_tta_tour.extend( {} );
})( window.jQuery );