<?php
/**
 * Wizard page header template
 */
?>
<div class="wrap">
	<div class="tm-wizard">
