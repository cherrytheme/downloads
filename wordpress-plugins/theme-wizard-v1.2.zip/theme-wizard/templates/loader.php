<?php
/**
 * Plugin item loader
 */
?>
<div class="tm-wizard-loader"><div class="tm-wizard-loader__spinner"></div></div>