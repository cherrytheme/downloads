<?php
/**
 * Page footer template
 */
?>
	<?php tm_wizard()->get_template( 'select-type-popup.php' ); ?>
	</div>
</div>

<?php do_action( 'tm_wizard_main_after' ); ?>
