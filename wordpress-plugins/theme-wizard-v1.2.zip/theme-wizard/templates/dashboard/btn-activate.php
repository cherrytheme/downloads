<?php
/**
 * Activate button template
 */
?>
<button data-action="activate" class="wizard-plugin__activate wizard-plugin__link"><span class="text"><?php
		esc_html_e( 'Activate', 'tm-wizard' );
	?></span><span class="tm-wizard-loader"><span class="tm-wizard-loader__spinner"></span></span>
</buttom>