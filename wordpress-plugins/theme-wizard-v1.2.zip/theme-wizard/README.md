# TM Wizard
Plugins installation wizard for WordPress 
