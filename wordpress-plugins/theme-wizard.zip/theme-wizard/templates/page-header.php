<?php
/**
 * Wizard page header template
 */
?>
<div class="wrap">
	<div class="theme-wizard">
