<?php
/**
 * Plugin item loader
 */
?>
<div class="theme-wizard-loader"><div class="theme-wizard-loader__spinner"></div></div>