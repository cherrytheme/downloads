<?php
/**
 * Install complete page
 */
?>
<h2><?php esc_html_e( 'Congratulations', 'theme-wizard' ); ?></h2>
<?php esc_html_e( 'Install complete', 'theme-wizard' ); ?>