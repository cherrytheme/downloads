<?php
/**
 * Plugins install template
 */
?>
<h2><?php esc_html_e( 'Install Plugins', 'theme-wizard' ); ?></h2>

<div class="theme-wizard-msg"><?php esc_html_e( 'Before demo data import a set of required plugins will be installed. Please be patient, this may take few minutes.', 'theme-wizard' ); ?></div>

<div class="theme-wizard-progress">
	<div class="theme-wizard-progress__bar">
		<span class="theme-wizard-progress__label"><span></span></span>
	</div>
</div>

<div class="theme-wizard-plugins">

</div>