<?php
/**
 * Plugin item template
 */
?>
<div class="theme-wizard-item" data-plugin="%1$s">
	%3$s
	<div class="theme-wizard-item__label"><?php esc_html_e( 'Install Plugin', 'theme-wizard' ); ?>: <b>%2$s</b></div>
</div>