<?php 

// Silence is golden ;)

?>