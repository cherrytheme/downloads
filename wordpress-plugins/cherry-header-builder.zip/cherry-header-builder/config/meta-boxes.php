<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Header Builder Meta Boxes changes.
 *
 * @var $config array Framework- and theme-defined metaboxes config
 *
 * @return array Changed config
 */

foreach ( $config as &$cfg ) {
	if ( $cfg['id'] === 'cherry_page_settings' ) {
		$cfg['fields'] = cherry_array_merge_insert(
			$cfg['fields'], array(
				'cherry_header_id' => array(
					'title' => _x( 'Header', 'site top area', 'cherry' ),
					'description' => sprintf( __( 'You can edit selected header or create a new one on the %s page', 'cherry' ), '<a href="' . admin_url() . 'edit.php?post_type=cherry_header" target="_blank">' . _x( 'Headers', 'site top area', 'cherry' ) . '</a>' ),
					'type' => 'select',
					'options' => cherry_array_merge(
						array(
							'' => __( 'Default (from Theme Options)', 'cherry' ),
						), ushb_get_existing_headers()
					),
					'show_if' => array( 'cherry_header', '=', 'custom' ),
				),
				'cherry_header_sticky_override' => array(
					'title' => __( 'Sticky Header', 'cherry' ),
					'type' => 'switch',
					'text' => __( 'Override this setting', 'cherry' ),
					'std' => 0,
					'show_if' => array( 'cherry_header', '=', 'custom' ),
				),
				'cherry_header_sticky' => array(
					'type' => 'checkboxes',
					'options' => array(
						'default' => __( 'On Desktops', 'cherry' ),
						'tablets' => __( 'On Tablets', 'cherry' ),
						'mobiles' => __( 'On Mobiles', 'cherry' ),
					),					
					'std' => array(),
					'classes' => 'for_above',
					'show_if' => array(
						array( 'cherry_header', '=', 'custom' ),
						'and',
						array( 'cherry_header_sticky_override', '=', '1' ),
					),
				),			
				'cherry_header_transparent_override' => array(
					'title' => __( 'Transparent Header', 'cherry' ),
					'type' => 'switch',
					'text' => __( 'Override this setting', 'cherry' ),
					'std' => 0,
					'show_if' => array( 'cherry_header', '=', 'custom' ),
				),
				'cherry_header_transparent' => array(
					'type' => 'checkboxes',
					'options' => array(
						'default' => __( 'On Desktops', 'cherry' ),
						'tablets' => __( 'On Tablets', 'cherry' ),
						'mobiles' => __( 'On Mobiles', 'cherry' ),
					),					
					'std' => array(),
					'classes' => 'for_above',
					'show_if' => array(
						array( 'cherry_header', '=', 'custom' ),
						'and',
						array( 'cherry_header_transparent_override', '=', '1' ),
					),
				),
				'cherry_header_shadow' => array(
					'title' => __( 'Header Shadow', 'cherry' ),
					'type' => 'switch',
					'text' => __( 'Remove header shadow', 'cherry' ),
					'std' => 0,
					'show_if' => array( 'cherry_header', '=', 'custom' ),
				),
			), 'after', 'cherry_header'
		);
		break;
	}
}

return $config;