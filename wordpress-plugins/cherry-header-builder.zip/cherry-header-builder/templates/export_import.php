<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Output export-import dialog
 */

?>
<div class="cherry-hb-window for_export_import">
	<div class="cherry-hb-window-h">
		<div class="cherry-hb-window-header">
			<div class="cherry-hb-window-title"><?php _e( 'Header Export / Import', 'cherry' ) ?></div>
			<div class="cherry-hb-window-closer" title="<?php echo cherry_translate( 'Close' ) ?>"></div>
		</div>
		<div class="cherry-hb-window-body usof-container">
			<div class="usof-form-row type_transfer desc_2">
				<div class="usof-form-row-field">
					<div class="usof-form-row-control">
						<textarea></textarea>
					</div>
					<div class="usof-form-row-desc">
						<div class="usof-form-row-desc-icon"></div>
						<div class="usof-form-row-desc-text"><?php _e( 'You can export the saved Header by copying the text inside this field. To import another Header replace the text in this field and click "Import Header" button.', 'cherry' ) ?></div>
					</div>
					<div class="usof-form-row-state"><?php echo cherry_translate( 'Invalid data provided.' ) ?></div>
				</div>
			</div>
		</div>
		<div class="cherry-hb-window-footer">
			<div class="cherry-hb-window-btn for_close"><span><?php echo cherry_translate( 'Close' ) ?></span></div>
			<div class="cherry-hb-window-btn for_save"><span><?php _e( 'Import Header', 'cherry' ) ?></span></div>
		</div>
	</div>
</div>
