<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Output elements list to choose from
 */

global $cl_uri;
$elements = cherry_config( 'header-settings.elements', array() );

$output = '<div class="cherry-hb-window for_adding"><div class="cherry-hb-window-h"><div class="cherry-hb-window-header">';
$output .= '<div class="cherry-hb-window-title">' . __( 'Add element', 'cherry' ) . '</div>';
$output .= '<div class="cherry-hb-window-closer" title="' . cherry_translate( 'Close' ) . '"></div></div>';
$output .= '<div class="cherry-hb-window-body"><ul class="cherry-hb-window-list">';
foreach ( $elements as $name => $elm ) {
	if ( isset( $elm['place_if'] ) AND $elm['place_if'] === FALSE ) {
		continue;
	}
	$output .= '<li class="cherry-hb-window-item type_' . $name . '" data-name="' . $name . '"><div class="cherry-hb-window-item-h">';
	$output .= '<div class="cherry-hb-window-item-icon"';
	if ( isset( $elm['icon'] ) AND ! empty( $elm['icon'] ) ) {
		$output .= ' style="background-image: url(' . $elm['icon'] . ')';
	}
	$output .= '></div>';
	$output .= '<div class="cherry-hb-window-item-title">' . ( isset( $elm['title'] ) ? $elm['title'] : $name ) . '</div>';
	if ( isset( $elm['description'] ) AND ! empty( $elm['description'] ) ) {
		$output .= '<div class="cherry-hb-window-item-description">' . $elm['description'] . '</div>';
	}
	$output .= '</div></li>';
}
$output .= '</ul></div></div></div>';

echo $output;

