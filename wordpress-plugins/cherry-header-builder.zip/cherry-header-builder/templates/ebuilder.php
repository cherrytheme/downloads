<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Output elements builder
 *
 * @var $titles array Elements titles
 * @var $body string Body inner HTML
 */
$titles = ( isset( $titles ) AND is_array( $titles ) ) ? $titles : array();
$body = isset( $body ) ? $body : '';

?>
<div class="cherry-hb-window for_editing">
	<div class="cherry-hb-window-h">
		<div class="cherry-hb-window-header">
			<div class="cherry-hb-window-title"<?php echo cherry_pass_data_to_js($titles) ?>></div>
			<div class="cherry-hb-window-closer" title="<?php echo cherry_translate( 'Close' ) ?>"></div>
		</div>
		<div class="cherry-hb-window-body usof-container"><?php echo $body ?><span class="usof-preloader"></span></div>
		<div class="cherry-hb-window-footer">
			<div class="cherry-hb-window-btn for_close"><span><?php echo cherry_translate( 'Close' ) ?></span></div>
			<div class="cherry-hb-window-btn for_save"><span><?php echo cherry_translate( 'Save Changes' ) ?></span></div>
		</div>
	</div>
</div>
