<?php
/**
 * Install button template
 */
?>
<button data-action="install" class="wizard-plugin__install wizard-plugin__link"><span class="text"><?php
		esc_html_e( 'Install', 'cherry-plugin-wizard' );
	?></span><span class="cherry-plugin-wizard-loader"><span class="cherry-plugin-wizard-loader__spinner"></span></span>
</buttom>