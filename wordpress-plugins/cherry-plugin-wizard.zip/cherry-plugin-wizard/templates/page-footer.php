<?php
/**
 * Page footer template
 */
?>
	<?php cherry_plugin_wizard()->get_template( 'select-type-popup.php' ); ?>
	</div>
</div>

<?php do_action( 'cherry_plugin_wizard_main_after' ); ?>
