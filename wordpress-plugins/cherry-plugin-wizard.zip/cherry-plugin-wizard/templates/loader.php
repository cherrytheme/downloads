<?php
/**
 * Plugin item loader
 */
?>
<div class="cherry-plugin-wizard-loader"><div class="cherry-plugin-wizard-loader__spinner"></div></div>