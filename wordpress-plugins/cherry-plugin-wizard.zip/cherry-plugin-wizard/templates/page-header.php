<?php
/**
 * Wizard page header template
 */
?>
<div class="wrap">
	<div class="cherry-plugin-wizard">
