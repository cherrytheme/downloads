<?php
/**
 * Plugin item template
 */
?>
<div class="cherry-plugin-wizard-item" data-plugin="%1$s">
	%3$s
	<div class="cherry-plugin-wizard-item__label"><?php esc_html_e( 'Install Plugin', 'cherry-plugin-wizard' ); ?>: <b>%2$s</b></div>
</div>