<?php
/**
 * Install complete page
 */
?>
<h2><?php esc_html_e( 'Congratulations', 'cherry-plugin-wizard' ); ?></h2>
<?php esc_html_e( 'Install complete', 'cherry-plugin-wizard' ); ?>